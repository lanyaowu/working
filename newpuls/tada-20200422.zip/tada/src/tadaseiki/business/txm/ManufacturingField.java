package tadaseiki.business.txm;

import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.TxStarView;
import tadaseiki.record.Enum.ManufacturingType;
import tadaseiki.record.Manufacturing;

public final class ManufacturingField
    extends TxStarView.FieldOf.AndLongFK<Manufacturing> {

    public Mandatory<Long> ManufacturingId() { return super.PK(); }
    public Mandatory<Long> OrderId() { return super.FK(); }
    public final Mandatory<String> Number = attr(Manufacturing.Number.class);
    public final Mandatory<ManufacturingType> Type = asEnum(Manufacturing.Type.class);
}
