package tadaseiki.business.txm;

import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.TxStarView;
import tadaseiki.record.Order;

public final class OrderField
    extends TxStarView.FieldOf.AndIntFK<Order> {

    public Mandatory<Long> OrderId() { return super.PK(); }
    public Mandatory<Integer> CustomerId() { return super.FK(); }
}
