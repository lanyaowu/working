package tadaseiki.business;

import aloha3.module.function.business.ServiceContainer;
import aloha3.module.function.business.master.CoreMgr;
import aloha3.module.function.business.transaction.TxIntFKMgr;
import aloha3.module.function.business.transaction.TxLongFKMgr;
import tadaseiki.business.mdm.*;
import tadaseiki.business.txm.ManufacturingField;
import tadaseiki.business.txm.OrderField;
import tadaseiki.record.*;

public class Service {

    public static final ServiceContainer container;

    static {
        container = new ServiceContainer();
        container.eagerLoad(Accessor.class);
    }

    public static class Accessor
        implements ServiceContainer.Accessor {

        public static
        CoreMgr.StarView <
            Customer,
            CustomerField>
        customerMgr() {
            return container.getOrAddCoreMgrOf(CustomerField.class);
        }
        public static
        CoreMgr.StarView <
            Product,
            ProductField>
        productMgr() {
            return container.getOrAddCoreMgrOf(ProductField.class);
        }
        public static
        TxIntFKMgr.StarView <
            Order,
            Customer,
            OrderField>
        orderMgr() {
            return container.getOrAddTxIntFKMgrOf(OrderField.class);
        }
        public static
        TxLongFKMgr.StarView <
            Manufacturing,
            Order,
            ManufacturingField>
        manufacturingMgr() {
            return container.getOrAddTxLongFKMgrOf(ManufacturingField.class);
        }
    } // Accessor
}
