package tadaseiki.business.mdm;

import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.AbstractField.Member.Optional;
import aloha3.module.object.view.StarView;
import tadaseiki.record.ProductPart;

public final class ProductPartField
        extends StarView.FieldOf.ForeignCore<ProductPart,ProductPart.Product> {

        public Mandatory<Integer> ProductPartId() { return super.coreMember(); }
        public Mandatory<Integer> ProductId() { return super.foreignCore(); }
        public final Mandatory<String> Code = attr(ProductPart.Code.class);
        public final Optional<Integer> DerivedToGraphId = optAFK(ProductPart.DerivedTo.class);
}
