package tadaseiki.business.mdm;

import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.StarView;
import tadaseiki.record.Customer;

public final class CustomerField
    extends StarView.FieldOf<Customer> {
        public Mandatory<Integer> CustomerId() { return super.coreMember(); }
        public final Mandatory<String> Code = attr(Customer.Code.class);
        public final Mandatory<String> Name = attr(Customer.Name.class);
}
