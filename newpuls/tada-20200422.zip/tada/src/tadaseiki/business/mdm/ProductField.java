package tadaseiki.business.mdm;

import aloha3.module.object.view.AbstractField.Member.Mandatory;
import aloha3.module.object.view.StarView;
import tadaseiki.record.Product;

public final class ProductField
    extends StarView.FieldOf<Product> {

        public Mandatory<Integer> ProductId() { return super.coreMember(); }
        public final Mandatory<String> Code = attr(Product.Code.class);
}
