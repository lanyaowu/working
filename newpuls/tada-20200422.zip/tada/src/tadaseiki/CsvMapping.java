package tadaseiki;


import aloha.module.func.Func;
import aloha.module.object.DateTime;
import aloha.module.object.ImmutVOs;
import aloha3.dml.master.InsertView;
import aloha3.module.object.view.Field;
import aloha3.tool.controller.CsvLine;
import aloha3.tool.controller.CsvMappingTo;
import tadaseiki.business.mdm.CustomerField;
import tadaseiki.business.mdm.ProductField;
import tadaseiki.business.mdm.ProductPartField;
import tadaseiki.record.Customer;
import tadaseiki.record.Product;
import tadaseiki.record.ProductPart;
import tadaseiki.tool.InitDB;

public class CsvMapping {

    static{
        InitDB.initProps();
    }

    public static void main(String[] args) {

        loadCustomer(
            ImmutVOs.create(
                CsvLine.toCsvLine("D0001,デンソー"),
                CsvLine.toCsvLine("T0002,東京理化")));

        loadCustomer(
            ImmutVOs.create(
                CsvLine.toCsvLine("D0001,DENSO"),
                CsvLine.toCsvLine("T0002,東京理化")));

        loadProduct(
            defineCsv(),
            ImmutVOs.create(
                CsvLine.toCsvLine("GD001,1010"),
                CsvLine.toCsvLine("GD001,2010"),
                CsvLine.toCsvLine("GD002,1010"),
                CsvLine.toCsvLine("GD002,2010")));

        System.exit(0);
    }

    private static
    void
    loadCustomer(ImmutVOs<CsvLine> customers) {

        CsvMappingTo.upsertStatView(
            customers,
            DateTime.YMDHMS.current(),
            Customer.Code.class,
            CustomerField.class,
            f->f.Code,
            f->f.Name);
    }

    private static
    CsvLine.Definition
    defineCsv() {
        return Func.apply(
            Field.instanceOf(ProductField.class),
            Field.instanceOf(ProductPartField.class),
            (product,productPart)->
                CsvLine.Definition.create(
                    product.Code,
                    productPart.Code,
                    productPart.DerivedToGraphId));
    }

    private static
    void
    loadProduct(
        CsvLine.Definition definition,
        ImmutVOs<CsvLine> csvLines) {

        CsvMappingTo.
            upsertStatView(
                definition,
                csvLines,
                DateTime.YMDHMS.current(),
                Product.Code.class,
                ProductField.class,
                ProductPartField.class,
                (p,pp)->p.Code,
                (p,pp)->pp.Code);
    }
}
