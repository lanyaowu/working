package tadaseiki.record.Enum;

import aloha.module.object.IdentifiableEnum;
import aloha.module.object.ImmutableArray;

public enum ManufacturingType implements IdentifiableEnum<ManufacturingType> {
    NEW((byte)1),FIX((byte)2),MOD((byte)3);

    private final byte id;
    ManufacturingType(byte id) {
        this.id = id;
    }

    @Override
    public byte id() {
        return id;
    }

    @Override
    public ManufacturingType of(byte b) {
        return IdentifiableEnum.find(id,array);
    }

    static final ImmutableArray<ManufacturingType> array = IdentifiableEnum.toArray(ManufacturingType.class);
}
