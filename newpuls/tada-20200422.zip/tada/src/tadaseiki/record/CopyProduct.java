package tadaseiki.record;

import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.FixedAttributeEntity;
import aloha3.module.object.record.master.FixedAttributeEntityAFK;
import tadaseiki.mapping.Properties.DB_GROUP;

public final class CopyProduct extends CoreEntity {
    @Override
    public DB_GROUP dbGroup() {
        return DB_GROUP.PRODUCT;
    }

    public final static class From
        extends FixedAttributeEntityAFK.Of<CopyProduct,Product> {}

    public final static class To
        extends FixedAttributeEntityAFK.Of<CopyProduct,Product> {}
}