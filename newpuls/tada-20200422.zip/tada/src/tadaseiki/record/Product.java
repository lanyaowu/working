package tadaseiki.record;

import aloha3.module.object.record.master.AttributeEntity;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.FixedAttributeEntity;
import aloha3.module.object.record.master.FixedAttributeEntityAFK;
import tadaseiki.mapping.Properties.DB_GROUP;

public final class Product extends CoreEntity {
    @Override
    public DB_GROUP dbGroup() {
        return DB_GROUP.PRODUCT;
    }

    public final static class Code // 製造番号
        extends FixedAttributeEntity.UniqueString<Product> {}
}