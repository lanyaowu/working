package tadaseiki.record;

import aloha3.module.object.record.master.AttributeEntity;
import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.FixedAttributeEntity;
import tadaseiki.mapping.Properties.DB_GROUP;

public final class Customer extends CoreEntity {
    @Override
    public DB_GROUP dbGroup() {
        return DB_GROUP.CUSTOMER;
    }

    public final static class Code
        extends FixedAttributeEntity.UniqueString<Customer> {}
    public final static class Name
        extends AttributeEntity.Of<Customer,String> {}
}