package tadaseiki.record;

import aloha3.module.object.record.master.HierarchyEntity;

public final class DerivedProductPart
    extends HierarchyEntity.Of.Tree<ProductPart> {
}
