package tadaseiki.record;

import aloha3.module.object.record.master.CoreEntity;
import aloha3.module.object.record.master.FixedAttributeEntity;
import aloha3.module.object.record.master.FixedAttributeEntityAFK;
import aloha3.module.object.record.master.coc.Graph;
import tadaseiki.mapping.Properties;

public final class ProductPart extends CoreEntity {

    @Override
    public Properties.DB_GROUP dbGroup() {
        return Properties.DB_GROUP.PRODUCT;
    }

    public  static final class Code
        extends FixedAttributeEntity.Of<ProductPart,String> {}

    public static final class Product
        extends FixedAttributeEntityAFK.Of<ProductPart, tadaseiki.record.Product> {}

    public static final class DerivedTo
        extends FixedAttributeEntityAFK.Of<ProductPart, Graph> {}
}
