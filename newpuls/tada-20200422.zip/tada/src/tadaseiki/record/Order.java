package tadaseiki.record;

import aloha3.module.object.record.transaction.TxAttributeEntity;
import aloha3.module.object.record.transaction.TxEntityIntFK;
import tadaseiki.mapping.Properties;

public final class Order
    extends TxEntityIntFK.On<Customer> {

    public Order() {
        super("ORDER_");
    }
    @Override
    public Properties.DB_GROUP dbGroup() {
        return Properties.DB_GROUP.ORDER;
    }
}
