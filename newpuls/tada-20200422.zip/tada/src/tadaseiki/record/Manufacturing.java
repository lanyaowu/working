package tadaseiki.record;

import aloha3.module.object.record.transaction.TxAttributeEntity;
import aloha3.module.object.record.transaction.TxEntityLongFK;
import tadaseiki.mapping.Properties;
import tadaseiki.record.Enum.ManufacturingType;

public final class Manufacturing
    extends TxEntityLongFK.On<Order> {

    @Override
    public Properties.DB_GROUP dbGroup() {
        return Properties.DB_GROUP.MANUFACTURING;
    }

    public static final class Number
        extends TxAttributeEntity.Of<Manufacturing,String> {}

    public static final class Type
        extends TxAttributeEntity.EnumOf<Manufacturing, ManufacturingType> {}
}
