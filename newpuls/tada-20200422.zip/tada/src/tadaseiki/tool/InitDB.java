package tadaseiki.tool;

import aloha.mapping.Properties;
import aloha.mapping.write.Persist;
import aloha3.tool.ddl.util.TableInitializer;
import aloha3.tool.dml.insert.InitSurrogateKey;

public class InitDB {

    public static final Package[] recordPackages =
            new Package[]{
                tadaseiki.record.Customer.class.getPackage()};

    public static void main(String...args) {

        try {
            initProps();
            TableInitializer.createTables(
                DC.class,AP_NODE.class,LAST_DIGIT.class,
                recordPackages);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    private static volatile boolean done = false;
    public static synchronized Persist.Nothing initProps() {
        if ( done )
            return Persist.IN_CASE_OF_NO_INSERT;
        Properties.setProps( new tadaseiki.mapping.Properties() );
        done = true;
        return Persist.IN_CASE_OF_NO_INSERT;
    }

    public enum DC implements InitSurrogateKey.DataCenter {
        YOKOHAMA(1);
        private final int id;
        DC(int id) {
            this.id = id;
        }
        @Override
        public int dataCenterId() {
            return this.id;
        }
    }

    public enum AP_NODE implements InitSurrogateKey.ApNode {
        MYPC(1, DC.YOKOHAMA);
        private final int id;
        private final DC dc;
        AP_NODE(int id, DC dc) {
            this.id = id;
            this.dc = dc;
        }
        @Override
        public int apNodeId() {
            return this.id;
        }
        @Override
        public int dataCenterId() {
            return this.dc.id;
        }
        @Override
        public String NAME() {
            return this.name();
        }
    }

    public enum LAST_DIGIT implements InitSurrogateKey.LastDigit {
        ZERO('0', AP_NODE.MYPC);
        private final char ch;
        private final AP_NODE ap;
        LAST_DIGIT(char ch, AP_NODE ap) {
            this.ch = ch;
            this.ap = ap;
        }
        @Override
        public int lastDigitAsInt() {
            return Integer.parseInt(
                String.valueOf(this.ch));
        }
        @Override
        public int apServerId() {
            return this.ap.apNodeId();
        }
        @Override
        public AP_NODE apNode() {
            return this.ap;
        }
    }
}
