package tadaseiki.mapping;

import aloha.concurrent.Context;
import aloha.mapping.DBConnectProp;
import aloha.mapping.IDbGroup;
import aloha.mapping.IDbNumber;
import aloha.mapping.IPool;
import aloha.mapping.IPools;
import aloha.mapping.IProperties;
import aloha.mapping.Pools;

import java.util.Map;

public class Properties implements IProperties {

    public enum DB_GROUP implements IDbGroup {
        CUSTOMER,
        PRODUCT,
        ORDER,
        MANUFACTURING,
        MISC,
    }
    // JDBC driver name and database URL

    static final String JDBC_DRIVER = "org.h2.Driver";
    static final String JDBC_URL = "jdbc:h2:~/tadaseiki;MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE;AUTO_SERVER=TRUE;";

    @Override
    public void init(Map<IDbGroup, IPools> resources) {

        try {
            Class.forName(JDBC_DRIVER);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        DBConnectProp dbProp = new DBConnectProp(
            IDbNumber.DB_NUMBER.ONE,
            IPool.DB_LOCATION.LOCAL,
            JDBC_URL,
            "sa",
            "",
            Context.numberOfCoresPerNUMANode(),
            IPool.MODE.READ_WRITE);

        IPools pools = new
            Pools(
                dbProp
        );

        for (DB_GROUP dbGroup : DB_GROUP.values()) {
            resources.put(dbGroup, pools);
        }
    }

    @Override
    public
    PRINT_SQL
    debug() {
        return PRINT_SQL.EXCEPT_OF_SELECT;
    }
 }


