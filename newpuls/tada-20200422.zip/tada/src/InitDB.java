import aloha.module.object.DateTime;
import tadaseiki.business.Service;

public class InitDB {

    public static void main(String[] args) {

        tadaseiki.tool.InitDB.main();

        Service.
            Accessor.customerMgr().
            selectAllCores(DateTime.YMDHMS.current()).
            foreach(System.out::println);

        System.exit(0);
    }
}

