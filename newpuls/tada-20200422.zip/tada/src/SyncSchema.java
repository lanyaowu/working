import aloha.mapping.DBCP;
import aloha.mapping.IDbNumber.DB_NUMBER;
import aloha.module.func.Func;
import aloha3.tool.sql.Diff;
import tadaseiki.tool.InitDB.LAST_DIGIT;

public class SyncSchema {

    static {
        tadaseiki.tool.InitDB.initProps();
    }

    public static void main(String... args) {

        Func.accept(
            DBCP.assertSinglePools(),
            pools-> Diff.
                renameGarbageTable(
                    pools,
                    DB_NUMBER.ONE,
                    tadaseiki.tool.InitDB.recordPackages),
            pools-> Diff.
                addTableIfNotYet(
                    pools,
                    DB_NUMBER.ONE,
                    LAST_DIGIT.class,
                    tadaseiki.tool.InitDB.recordPackages),
            pools->
                System.exit(0));
    }
}
