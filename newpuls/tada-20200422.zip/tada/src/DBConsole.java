import java.sql.SQLException;

public class DBConsole {

    public static void main(String[] args) throws SQLException {
        org.h2.tools.Console.main(args);
    }
}
